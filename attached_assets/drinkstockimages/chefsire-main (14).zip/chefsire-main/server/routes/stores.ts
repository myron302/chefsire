import { Router } from "express";

const router = Router();

/**
 * SQUARE PAYMENT ROUTES
 * ----------------------
 * This file is for Square payment integration routes.
 * Store management routes are in stores-crud.ts
 */

// TODO: Add Square payment routes here if needed

export default router;
