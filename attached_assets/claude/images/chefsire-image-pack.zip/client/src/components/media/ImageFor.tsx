import * as React from 'react';
import { getImagePath, type Domain, type Variant } from '@/lib/imagePaths';

type Props = {
  domain: Domain;
  group: string;
  subtype?: string;
  variant?: Variant;
  alt?: string;
  className?: string;
  imgProps?: React.ImgHTMLAttributes<HTMLImageElement>;
  fallbackSrc?: string;
};

export default function ImageFor({
  domain,
  group,
  subtype,
  variant = 'card',
  alt,
  className,
  imgProps,
  fallbackSrc
}: Props) {
  const src = React.useMemo(() => getImagePath(domain, group, variant, subtype), [domain, group, variant, subtype]);
  const [err, setErr] = React.useState(false);
  const finalSrc = err && fallbackSrc ? fallbackSrc : src;
  return (
    <img
      src={finalSrc}
      alt={alt ?? `${domain} ${group}${subtype ? ' ' + subtype : ''}`}
      className={className}
      onError={() => setErr(true)}
      {...imgProps}
    />
  );
}
