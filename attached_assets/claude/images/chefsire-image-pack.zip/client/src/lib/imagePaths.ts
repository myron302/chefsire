export type Domain = 'drinks' | 'petfood' | 'baby-food';
export type Variant = 'hub' | 'card';
export const IMAGE_BASE = '/assets/images';
export function getImagePath(domain: Domain, group: string, variant: Variant = 'card', subtype?: string): string {
  const safe = (s: string) => s.toLowerCase().replace(/\s+/g, '-');
  const d = safe(domain);
  const g = safe(group);
  if (subtype) {
    const s = safe(subtype);
    return `${IMAGE_BASE}/${d}/${g}/${s}/${variant === 'hub' ? 'hub.svg' : 'card.svg'}`;
  }
  return `${IMAGE_BASE}/${d}/${g}/${variant === 'hub' ? '_hub.svg' : '_card.svg'}`;
}
export const DrinksImage = (group: string, variant: Variant = 'card', subtype?: string) => getImagePath('drinks', group, variant, subtype);
export const PetFoodImage = (group: string, variant: Variant = 'card', subtype?: string) => getImagePath('petfood', group, variant, subtype);
export const BabyFoodImage = (group: string, variant: Variant = 'card', subtype?: string) => getImagePath('baby-food', group, variant, subtype);
