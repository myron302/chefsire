
# ChefSire Image Pack
Generated: 2025-10-25T22:20:35Z

**What this includes**
- Folder structure under `client/public/assets/images` for Drinks, Petfood, Baby Food.
- Original SVG placeholders (you own them) for **hub** (1600×900) and **card** (800×800) per group and subtype.
- A TS helper (`client/src/lib/imagePaths.ts`) and a React component (`client/src/components/media/ImageFor.tsx`) to reference images.

**Specs**
- Hub: 1600×900 (16:9), PNG/SVG
- Card: 800×800 (1:1), PNG/SVG
- File naming: `group/_hub.svg`, `group/_card.svg`, `group/subtype/hub.svg`, `group/subtype/card.svg`

**How to use**
```tsx
import ImageFor from '@/components/media/ImageFor';
import { getImagePath, DrinksImage } from '@/lib/imagePaths';

// Hub tile for Smoothies
<ImageFor domain="drinks" group="smoothies" variant="hub" className="w-full rounded-2xl" />

// Card thumbnail for Smoothies → Dessert
<ImageFor domain="drinks" group="smoothies" subtype="dessert" variant="card" className="w-40 h-40 rounded-xl object-cover" />

// Direct path
const src = getImagePath('drinks','smoothies','card','dessert'); // "/assets/images/drinks/smoothies/dessert/card.svg"
```

**What to provide (real photos/illustrations)**
- Drinks → Smoothies, Protein Shakes (Whey, Casein, Plant‑Based, Collagen, Egg, Beef), Detoxes (Juice, Tea, Water), Potent Potables (Vodka, Whiskey/Bourbon, Tequila/Mezcal, Rum, Cognac/Brandy, Scotch/Irish, Martinis, Cocktails, Seasonal, Mocktails).
- Petfood → Dogs (Kibble, Wet, Raw, Treats, Homemade); Cats (Kibble, Wet, Raw, Treats, Homemade).
- Baby Food → Purees (Fruits, Veggies, Proteins, Combos); Cereals (Rice, Oatmeal, Mixed); Finger‑Foods (Soft‑Fruits, Steamed‑Veggies, Puffs).

When you have final art, replace the SVGs with PNG/SVG of the same names so paths remain valid.
